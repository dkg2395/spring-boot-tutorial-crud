package com.example.springboottutorialdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTutorialDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
